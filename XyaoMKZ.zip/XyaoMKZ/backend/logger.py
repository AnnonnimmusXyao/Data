"""
XyaoTools Engine - Logger Service
Arch: Singleton Debugging Instance
"""

import PluginUtils  # type: ignore

_LOGGER_INSTANCE = None

def get_logger() -> PluginUtils.Logger:
    """Retorna la instancia única del Logger para XyaoTools."""
    global _LOGGER_INSTANCE
    if _LOGGER_INSTANCE is None:
        _LOGGER_INSTANCE = PluginUtils.Logger()
    return _LOGGER_INSTANCE

# Alias para importación directa: from logger import logger
logger = get_logger()