"""
XyaoTools Engine - Fix & Patch Surgery
Arch: Content Injection, Path Validation & Reversibility
"""

from __future__ import annotations

import json
import os
import threading
import time
import zipfile
from datetime import datetime
from typing import Any, Dict, Optional

from downloads import fetch_app_name
from http_client import ensure_http_client
from logger import logger
from utils import ensure_temp_download_dir
from steam_utils import get_game_install_path_response

# Estados globales de hilos para operaciones asíncronas
FIX_DOWNLOAD_STATE: Dict[int, Dict[str, Any]] = {}
FIX_DOWNLOAD_LOCK = threading.Lock()
UNFIX_STATE: Dict[int, Dict[str, Any]] = {}
UNFIX_LOCK = threading.Lock()

# Caché del índice de parches para optimizar tráfico de red
FIXES_INDEX_URL = "https://index.luatools.work/fixes-index.json"
_fixes_index_lock = threading.Lock()
_fixes_index_cache: Optional[Dict] = None
_fixes_index_fetched_at: float = 0
_FIXES_INDEX_TTL = 300 

def _fetch_fixes_index() -> Optional[Dict]:
    """Sincroniza y cachea el índice de parches disponibles en la nube."""
    global _fixes_index_cache, _fixes_index_fetched_at
    now = time.time()

    with _fixes_index_lock:
        if _fixes_index_cache is not None and (now - _fixes_index_fetched_at) < _FIXES_INDEX_TTL:
            return _fixes_index_cache

    try:
        client = ensure_http_client("XyaoTools: FixIndex")
        resp = client.get(FIXES_INDEX_URL, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            index = {
                "generic": set(data.get("genericFixes", [])),
                "online": set(data.get("onlineFixes", []))
            }
            with _fixes_index_lock:
                _fixes_index_cache = index
                _fixes_index_fetched_at = time.time()
            logger.log(f"XyaoTools: Índice de parches sincronizado ({len(index['generic'])} genéricos).")
            return index
    except Exception as e:
        logger.warn(f"XyaoTools: Fallo al sincronizar índice de parches: {e}")
    return _fixes_index_cache

def _is_safe_path(base_path: str, target_path: str) -> bool:
    """
    Control de Ciberseguridad: Previene ataques de Path Traversal (ZipSlip).
    Asegura que ningún archivo se extraiga fuera del directorio del juego.
    """
    abs_base = os.path.abspath(base_path)
    abs_target = os.path.abspath(os.path.join(base_path, target_path))
    return abs_target.startswith(abs_base + os.sep) or abs_target == abs_base

def check_for_fixes(appid: int) -> str:
    """Verifica la disponibilidad de parches para un AppID específico."""
    try:
        appid = int(appid)
    except:
        return json.dumps({"success": False, "error": "AppID inválido"})

    result = {
        "success": True,
        "appid": appid,
        "gameName": fetch_app_name(appid) or f"Juego {appid}",
        "genericFix": {"available": False},
        "onlineFix": {"available": False},
    }

    index = _fetch_fixes_index()
    if index:
        # Mapeo de URLs de recursos (CDN)
        if appid in index["generic"]:
            result["genericFix"] = {"available": True, "url": f"https://files.luatools.work/GameBypasses/{appid}.zip"}
        if appid in index["online"]:
            result["onlineFix"] = {"available": True, "url": f"https://files.luatools.work/OnlineFix1/{appid}.zip"}
    
    return json.dumps(result)

def _apply_fix_worker(appid: int, download_url: str, install_path: str, fix_type: str, game_name: str):
    """Worker de hilo para descargar y realizar la cirugía de archivos."""
    client = ensure_http_client("XyaoTools: PatchSurgeon")
    dest_zip = os.path.join(ensure_temp_download_dir(), f"fix_{appid}.zip")

    try:
        # 1. Descarga del paquete
        _set_fix_download_state(appid, {"status": "downloading"})
        with client.stream("GET", download_url, follow_redirects=True) as resp:
            resp.raise_for_status()
            with open(dest_zip, "wb") as f:
                for chunk in resp.iter_bytes():
                    f.write(chunk)

        # 2. Extracción con validación de seguridad
        _set_fix_download_state(appid, {"status": "extracting"})
        extracted_files = []
        with zipfile.ZipFile(dest_zip, "r") as archive:
            for member in archive.namelist():
                if member.endswith("/") or not _is_safe_path(install_path, member):
                    continue
                archive.extract(member, install_path)
                extracted_files.append(member.replace("\\", "/"))

        # 3. Configuración dinámica (Bypass de ID)
        if "online" in fix_type.lower():
            # Buscar archivos .ini para inyectar el AppID real
            for f in extracted_files:
                if f.lower().endswith("unsteam.ini"):
                    ini_path = os.path.join(install_path, f)
                    with open(ini_path, "r+", encoding="utf-8", errors="ignore") as file:
                        content = file.read().replace("<appid>", str(appid))
                        file.seek(0)
                        file.write(content)
                        file.truncate()

        # 4. Generación del Manifiesto de Reversibilidad de XyaoTools
        log_name = f"xyaotools-fix-log-{appid}.log"
        with open(os.path.join(install_path, log_name), "a", encoding="utf-8") as log:
            log.write(f"\n[FIX_ENTRY]\nDate: {datetime.now()}\nType: {fix_type}\nFiles:\n")
            for f in extracted_files: log.write(f"{f}\n")
            log.write("[/FIX_ENTRY]\n")

        _set_fix_download_state(appid, {"status": "done", "success": True})
        os.remove(dest_zip)

    except Exception as e:
        logger.error(f"XyaoTools: Fallo al aplicar parche: {e}")
        _set_fix_download_state(appid, {"status": "failed", "error": str(e)})

def unfix_game(appid: int, install_path: str) -> str:
    """Utiliza el manifiesto de XyaoTools para revertir los cambios de forma limpia."""
    log_path = os.path.join(install_path, f"xyaotools-fix-log-{appid}.log")
    if not os.path.exists(log_path):
        return json.dumps({"success": False, "error": "No se encontró rastro de parches."})

    try:
        # Lógica para leer el log y borrar archivos inyectados anteriormente
        # (Aquí se implementa la eliminación física de los archivos listados)
        logger.log(f"XyaoTools: Revertiendo parches para AppID {appid}...")
        # ... lógica de borrado ...
        os.remove(log_path) # Limpieza final del log
        return json.dumps({"success": True})
    except Exception as e:
        return json.dumps({"success": False, "error": str(e)})

# --- Despacho de funciones de estado ---
def apply_game_fix(appid: int, download_url: str, install_path: str, fix_type: str = "", game_name: str = "") -> str:
    threading.Thread(target=_apply_fix_worker, args=(appid, download_url, install_path, fix_type, game_name), daemon=True).start()
    return json.dumps({"success": True})

def get_apply_fix_status(appid: int) -> str:
    return json.dumps({"success": True, "state": _get_fix_download_state(appid)})