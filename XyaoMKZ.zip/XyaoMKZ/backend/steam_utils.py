"""
XyaoTools Engine - Steam Infrastructure Utilities
Arch: System Interoperability & VDF Parsing
"""

from __future__ import annotations

import os
import re
import subprocess
import sys
from typing import Dict, Optional, Any

import Millennium  # type: ignore
from logger import logger

# Cache persistente en memoria para evitar llamadas costosas al I/O del sistema
_STEAM_PATH_CACHE: Optional[str] = None

def get_steam_path() -> str:
    """
    Motor unificado de detección de ruta de Steam.
    Prioridades: Cache > Registro (HKCU) > Registro (HKLM) > Millennium API.
    """
    global _STEAM_PATH_CACHE
    if _STEAM_PATH_CACHE and os.path.exists(_STEAM_PATH_CACHE):
        return _STEAM_PATH_CACHE

    discovered_path = None

    if sys.platform.startswith("win"):
        try:
            import winreg
            # Intento 1: Registro del Usuario Corriente (Más preciso para instalaciones estándar)
            for root in [winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE]:
                try:
                    with winreg.OpenKey(root, r"Software\Valve\Steam") as key:
                        val, _ = winreg.QueryValueEx(key, "SteamPath" if root == winreg.HKEY_CURRENT_USER else "InstallPath")
                        if val and os.path.exists(str(val)):
                            discovered_path = str(val).replace("/", "\\")
                            break
                except FileNotFoundError:
                    continue
        except Exception as exc:
            logger.warn(f"XyaoTools: Error accediendo al registro de Windows: {exc}")

    # Fallback: API de Millennium (Capa de abstracción del host)
    if not discovered_path:
        try:
            discovered_path = Millennium.steam_path()
        except Exception:
            pass

    if discovered_path:
        _STEAM_PATH_CACHE = discovered_path
        logger.log(f"XyaoTools: Infraestructura de Steam localizada en: {discovered_path}")
        return discovered_path
    
    return ""

def _parse_vdf_robust(content: str) -> Dict[str, Any]:
    """
    Parser VDF (Valve Data Format) optimizado.
    Maneja estructuras anidadas y elimina comentarios de forma eficiente.
    """
    result: Dict[str, Any] = {}
    stack = [result]
    current_key = None

    # Tokenización mediante Regex para manejar comillas y llaves de forma segura
    tokens = re.findall(r'"[^"]*"|\{|\}', content)
    
    for token in tokens:
        clean_token = token.strip('"')

        if clean_token == "{":
            if current_key:
                new_node = {}
                stack[-1][current_key] = new_node
                stack.append(new_node)
                current_key = None
        elif clean_token == "}":
            if len(stack) > 1:
                stack.pop()
        elif current_key is None:
            current_key = clean_token
        else:
            stack[-1][current_key] = clean_token
            current_key = None

    return result

def has_lua_for_app(appid: int) -> bool:
    """Verifica la existencia de scripts activos o desactivados para un AppID."""
    base = get_steam_path()
    if not base: return False

    stplug_path = os.path.join(base, "config", "stplug-in")
    return any(os.path.exists(os.path.join(stplug_path, f"{appid}.lua{ext}")) 
               for ext in ["", ".disabled"])

def get_game_install_path_response(appid: int) -> Dict[str, Any]:
    """
    Localiza la ruta física de instalación de un juego.
    Analiza libraryfolders.vdf para rastrear el juego en múltiples librerías.
    """
    try:
        appid_str = str(int(appid))
    except ValueError:
        return {"success": False, "error": "ID de aplicación inválido"}

    s_path = get_steam_path()
    vdf_path = os.path.join(s_path, "config", "libraryfolders.vdf")
    
    if not os.path.exists(vdf_path):
        return {"success": False, "error": "No se encontró libraryfolders.vdf"}

    try:
        with open(vdf_path, "r", encoding="utf-8") as f:
            data = _parse_vdf_robust(f.read())
        
        folders = data.get("libraryfolders", {})
        target_lib = None
        all_libs = []

        for entry in folders.values():
            if not isinstance(entry, dict): continue
            
            p = entry.get("path", "").replace("\\\\", "\\")
            if not p: continue
            all_libs.append(p)
            
            if appid_str in entry.get("apps", {}):
                target_lib = p
                break

        # Búsqueda exhaustiva si no está en libraryfolders (casos de desincronización)
        manifest_path = None
        if not target_lib:
            for lib in all_libs:
                candidate = os.path.join(lib, "steamapps", f"appmanifest_{appid_str}.acf")
                if os.path.exists(candidate):
                    target_lib, manifest_path = lib, candidate
                    break
        else:
            manifest_path = os.path.join(target_lib, "steamapps", f"appmanifest_{appid_str}.acf")

        if not target_lib or not manifest_path or not os.path.exists(manifest_path):
            return {"success": False, "error": "Juego no instalado"}

        with open(manifest_path, "r", encoding="utf-8") as f:
            manifest = _parse_vdf_robust(f.read())
        
        install_dir = manifest.get("AppState", {}).get("installdir", "")
        if not install_dir:
            return {"success": False, "error": "Directorio de instalación no definido"}

        full_path = os.path.normpath(os.path.join(target_lib, "steamapps", "common", install_dir))
        
        if not os.path.exists(full_path):
            return {"success": False, "error": "La ruta de instalación no existe físicamente"}

        return {
            "success": True, 
            "installPath": full_path, 
            "libraryPath": target_lib,
            "path": full_path # Compatibilidad con legacy frontend
        }

    except Exception as e:
        logger.error(f"XyaoTools: Error crítico localizando juego {appid}: {e}")
        return {"success": False, "error": str(e)}

def open_game_folder(path: str) -> bool:
    """Lanza el explorador de archivos del sistema en la ruta especificada."""
    if not path or not os.path.exists(path): return False
    try:
        norm_path = os.path.normpath(path)
        if sys.platform.startswith("win"):
            os.startfile(norm_path)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", norm_path])
        else:
            subprocess.Popen(["xdg-open", norm_path])
        return True
    except Exception as e:
        logger.warn(f"XyaoTools: No se pudo abrir la carpeta: {e}")
        return False