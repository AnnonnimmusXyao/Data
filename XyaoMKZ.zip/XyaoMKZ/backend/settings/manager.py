"""
XyaoTools Engine - Settings Manager
Arch: Configuration Persistence & API Key Management
"""

from __future__ import annotations
import json
import os
import threading
from typing import Any, Dict

from paths import backend_path
from logger import logger

SETTINGS_FILE = "xyao_settings.json"
_cached_settings: Dict[str, Any] = {}
_settings_lock = threading.Lock()

def _get_settings_path() -> str:
    return backend_path(SETTINGS_FILE)

def init_settings() -> None:
    """Inicializa y carga las configuraciones guardadas del usuario."""
    global _cached_settings
    path = _get_settings_path()
    
    with _settings_lock:
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    _cached_settings = json.load(f)
                logger.log("XyaoTools: Ajustes de usuario cargados correctamente.")
            except Exception as e:
                logger.warn(f"XyaoTools: Error al cargar ajustes (corrupción posible): {e}")
                _cached_settings = {}
        else:
            _cached_settings = {}

def save_settings() -> bool:
    """Escribe de forma segura los ajustes en el disco."""
    path = _get_settings_path()
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(_cached_settings, f, indent=2)
        return True
    except Exception as e:
        logger.error(f"XyaoTools: Error crítico al guardar ajustes: {e}")
        return False

def get_settings_payload() -> Dict[str, Any]:
    """Retorna los ajustes actuales para la interfaz frontend."""
    with _settings_lock:
        return {"settings": _cached_settings.copy()}

def apply_settings_changes(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Aplica los cambios enviados desde la interfaz de Steam."""
    global _cached_settings
    
    if not isinstance(payload, dict):
        return {"success": False, "error": "Payload inválido"}
    
    with _settings_lock:
        _cached_settings.update(payload)
        success = save_settings()
        
    if success:
        logger.log("XyaoTools: Nuevos ajustes guardados.")
        return {"success": True}
    else:
        return {"success": False, "error": "Error de I/O al guardar."}

def get_morrenus_api_key() -> str:
    """Extrae la API Key necesaria para ciertas fuentes de descarga."""
    with _settings_lock:
        return str(_cached_settings.get("morrenus_api_key", ""))

# Exportamos las funciones requeridas por main.py y api_manifest.py
__all__ = [
    "init_settings",
    "get_settings_payload",
    "apply_settings_changes",
    "get_morrenus_api_key"
]