"""
XyaoTools Engine - HTTP Client Manager
Arch: Connection Pooling & Resilience
"""

from typing import Optional
import httpx  # type: ignore
from config import HTTP_TIMEOUT_SECONDS
from logger import logger

_HTTP_CLIENT: Optional[httpx.Client] = None

def ensure_http_client(context: str = "") -> httpx.Client:
    """Inicializa y retorna el cliente HTTP compartido."""
    global _HTTP_CLIENT
    if _HTTP_CLIENT is None:
        prefix = f"{context}: " if context else ""
        logger.log(f"{prefix}Inicializando motor HTTPX para XyaoTools...")
        try:
            _HTTP_CLIENT = httpx.Client(timeout=HTTP_TIMEOUT_SECONDS)
            logger.log(f"{prefix}Cliente de red operativo.")
        except Exception as exc:
            logger.error(f"{prefix}Fallo crítico en el cliente de red: {exc}")
            raise
    return _HTTP_CLIENT

def get_http_client() -> httpx.Client:
    return ensure_http_client()

def close_http_client(context: str = "") -> None:
    """Cierra de forma segura el pool de conexiones."""
    global _HTTP_CLIENT
    if _HTTP_CLIENT:
        try:
            _HTTP_CLIENT.close()
        except:
            pass
        finally:
            _HTTP_CLIENT = None