"""
XyaoTools Engine - API Manifest Manager
Arch: External Source Synchronization & Validation
"""

from __future__ import annotations

import json
import os
from typing import Any, Dict, List

from config import (
    API_JSON_FILE,
    API_MANIFEST_PROXY_URL,
    API_MANIFEST_URL,
    HTTP_PROXY_TIMEOUT_SECONDS,
)
from http_client import ensure_http_client
from logger import logger
from utils import (
    backend_path,
    count_apis,
    normalize_manifest_text,
    read_text,
    write_text,
)
from settings.manager import get_morrenus_api_key

_APIS_INIT_DONE = False
_INIT_APIS_LAST_MESSAGE = ""

def init_apis(content_script_query: str = "") -> str:
    """Inicializa el manifiesto de APIs externas al arrancar el motor."""
    global _APIS_INIT_DONE, _INIT_APIS_LAST_MESSAGE
    
    if _APIS_INIT_DONE:
        logger.log("XyaoTools: InitApis ya completado en esta sesión.")
        return json.dumps({"success": True, "message": _INIT_APIS_LAST_MESSAGE})

    client = ensure_http_client("XyaoTools: Init")
    api_json_path = backend_path(API_JSON_FILE)
    message = ""

    # Prioridad: Archivo local persistente
    if os.path.exists(api_json_path):
        logger.log(f"XyaoTools: Cargando manifiesto local desde {api_json_path}")
    else:
        logger.log("XyaoTools: Manifiesto no encontrado. Iniciando sincronización remota...")
        manifest_text = ""
        try:
            # Intento 1: Servidor Principal
            try:
                resp = client.get(API_MANIFEST_URL)
                resp.raise_for_status()
                manifest_text = resp.text
            except Exception as primary_err:
                logger.warn(f"XyaoTools: Fallo en servidor principal, intentando proxy... ({primary_err})")
                # Intento 2: Proxy de Respaldo
                resp = client.get(API_MANIFEST_PROXY_URL, timeout=HTTP_PROXY_TIMEOUT_SECONDS)
                resp.raise_for_status()
                manifest_text = resp.text
        except Exception as fetch_err:
            logger.error(f"XyaoTools: Error crítico al obtener fuentes externas: {fetch_err}")

        normalized = normalize_manifest_text(manifest_text) if manifest_text else ""
        if normalized:
            write_text(api_json_path, normalized)
            count = count_apis(normalized)
            message = f"XyaoTools: Motor listo. {count} fuentes cargadas correctamente."
            logger.log(f"XyaoTools: Manifiesto generado con {count} entradas.")
        else:
            message = "XyaoTools: Error al configurar fuentes externas."
            logger.warn("XyaoTools: Manifiesto vacío o inválido.")

    _APIS_INIT_DONE = True
    _INIT_APIS_LAST_MESSAGE = message
    return json.dumps({"success": True, "message": message})

def get_init_apis_message(content_script_query: str = "") -> str:
    """Consume y retorna el último mensaje de estado para el frontend."""
    global _INIT_APIS_LAST_MESSAGE
    msg = _INIT_APIS_LAST_MESSAGE or ""
    _INIT_APIS_LAST_MESSAGE = "" # Limpieza atómica
    return json.dumps({"success": True, "message": msg})

def store_last_message(message: str) -> None:
    """Permite que otros módulos (como Auto-Update) inyecten mensajes en la UI."""
    global _INIT_APIS_LAST_MESSAGE
    _INIT_APIS_LAST_MESSAGE = message or ""

def fetch_free_apis_now(content_script_query: str = "") -> str:
    """Fuerza una resincronización manual de las APIs desde el repositorio."""
    client = ensure_http_client("XyaoTools: ForceSync")
    try:
        logger.log("XyaoTools: Forzando actualización de fuentes...")
        manifest_text = ""

        try:
            resp = client.get(API_MANIFEST_URL, follow_redirects=True)
            resp.raise_for_status()
            manifest_text = resp.text
        except Exception:
            resp = client.get(API_MANIFEST_PROXY_URL, follow_redirects=True, timeout=HTTP_PROXY_TIMEOUT_SECONDS)
            resp.raise_for_status()
            manifest_text = resp.text

        normalized = normalize_manifest_text(manifest_text)
        if not normalized:
            return json.dumps({"success": False, "error": "Manifiesto remoto vacío."})

        write_text(backend_path(API_JSON_FILE), normalized)
        count = count_apis(normalized)
        return json.dumps({"success": True, "count": count})
    except Exception as exc:
        logger.error(f"XyaoTools: Fallo en FetchFreeApisNow: {exc}")
        return json.dumps({"success": False, "error": str(exc)})

def load_api_manifest() -> List[Dict[str, Any]]:
    """Carga y retorna solo las fuentes habilitadas en el sistema."""
    path = backend_path(API_JSON_FILE)
    text = read_text(path)
    if not text:
        return []

    try:
        data = json.loads(text)
        apis = data.get("api_list", [])
        # Filtro de seguridad: solo APIs marcadas como habilitadas
        return [api for api in apis if api.get("enabled", False)]
    except Exception as exc:
        logger.error(f"XyaoTools: Error de parseo en api.json: {exc}")
        return []

def get_api_list(content_script_query: str = "") -> str:
    """Retorna la lista filtrada de nombres de APIs para el frontend."""
    try:
        apis = load_api_manifest()
        mo_key = get_morrenus_api_key()

        api_names = []
        for i, api in enumerate(apis):
            url = api.get("url", "")
            # Lógica de Seguridad: Ocultar fuentes Morrenus si no hay API Key configurada
            if "<moapikey>" in url and not mo_key:
                continue
            api_names.append({"name": api.get("name", "Fuente Desconocida"), "index": i})

        return json.dumps({"success": True, "apis": api_names})
    except Exception as exc:
        logger.error(f"XyaoTools: Error al generar lista de APIs: {exc}")
        return json.dumps({"success": False, "error": str(exc), "apis": []})