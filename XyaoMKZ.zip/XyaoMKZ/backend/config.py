"""
XyaoTools Engine - Central Configuration
Arch: Backend Constants
"""

# Identidad del Plugin
WEBKIT_DIR_NAME = "XyaoTools"
WEB_UI_JS_FILE = "xyaotools.js"
WEB_UI_ICON_FILE = "xyao.png"

# Configuración de Red (Optimizado para Ing. en Redes)
DEFAULT_HEADERS = {
    "Accept": "application/json",
    "X-Requested-With": "XyaoTools-Client",
    "User-Agent": "XyaoTools/1.0 (Cybersecurity Audit Mode)",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "cross-site",
}

# Endpoints (Mantener para compatibilidad, pero bajo nueva identidad)
API_MANIFEST_URL = "https://raw.githubusercontent.com/madoiscool/lt_api_links/refs/heads/main/load_free_manifest_apis"
API_MANIFEST_PROXY_URL = "https://luatools.vercel.app/load_free_manifest_apis"
API_JSON_FILE = "api.json"

# Sistema de Actualización
UPDATE_CONFIG_FILE = "update.json"
UPDATE_PENDING_ZIP = "update_pending.zip"
UPDATE_PENDING_INFO = "update_pending.json"

# Timeouts de Red (Tiempos de espera ajustados para mayor fiabilidad)
HTTP_TIMEOUT_SECONDS = 20
HTTP_PROXY_TIMEOUT_SECONDS = 15

# Ciclo de Vida
UPDATE_CHECK_INTERVAL_SECONDS = 7200  # 2 Horas
USER_AGENT = "XyaoTools-Global-Agent"

# Persistencia de Datos
LOADED_APPS_FILE = "xyao_apps.txt"
APPID_LOG_FILE = "xyao_audit_log.txt"