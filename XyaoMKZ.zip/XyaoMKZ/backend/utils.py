"""
XyaoTools Engine - Generic Utilities
Arch: Data Integrity, Versioning & Manifest Normalization
"""

from __future__ import annotations
import json
import os
import re
from typing import Any, Dict

from paths import backend_path, get_plugin_dir

def read_text(path: str) -> str:
    """Lee un archivo de texto de forma segura."""
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return handle.read()
    except Exception:
        return ""

def write_text(path: str, text: str) -> None:
    """Escribe texto asegurando codificación UTF-8."""
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)

def read_json(path: str) -> Dict[str, Any]:
    """Lee JSON con manejo de excepciones silencioso para estabilidad."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return {}

def write_json(path: str, data: Dict[str, Any]) -> bool:
    """Escritura JSON con indentación para auditoría humana."""
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return True
    except Exception as e:
        from logger import logger
        logger.error(f"XyaoTools: Fallo de integridad al escribir {path}: {e}")
        return False

def count_apis(text: str) -> int:
    """Analiza el manifiesto para contar fuentes disponibles."""
    try:
        data = json.loads(text)
        return len(data.get("api_list", []))
    except:
        return text.count('"name"')

def normalize_manifest_text(text: str) -> str:
    """Sanitiza el JSON del manifiesto para corregir errores comunes de formato."""
    content = (text or "").strip()
    if not content:
        return content

    content = re.sub(r",\s*]", "]", content)
    content = re.sub(r",\s*}\s*$", "}", content)

    if content.startswith('"api_list"') or content.startswith("'api_list'") or content.startswith("api_list"):
        if not content.startswith("{"):
            content = "{" + content
        if not content.endswith("}"):
            content = content.rstrip(",") + "}"

    try:
        json.loads(content)
        return content
    except Exception:
        return text

def parse_version(version: str) -> tuple:
    """Convierte strings de versión en tuplas comparables (ej: '2.4' -> (2, 4))."""
    try:
        return tuple(int(p) for p in re.findall(r"\d+", str(version))) or (0,)
    except:
        return (0,)

def get_plugin_version() -> str:
    """Extrae la versión actual del manifiesto oficial del plugin."""
    try:
        plugin_json_path = os.path.join(get_plugin_dir(), "plugin.json")
        data = read_json(plugin_json_path)
        return str(data.get("version", "0.1.0"))
    except:
        return "0.1.0"

def ensure_temp_download_dir() -> str:
    """Garantiza la existencia del sandbox para descargas temporales."""
    path = backend_path("xyao_temp")
    os.makedirs(path, exist_ok=True)
    return path

# Exportar las funciones para que otros módulos las encuentren sin problemas
__all__ = [
    "backend_path",
    "get_plugin_dir",
    "read_text",
    "write_text",
    "read_json",
    "write_json",
    "count_apis",
    "normalize_manifest_text",
    "parse_version",
    "get_plugin_version",
    "ensure_temp_download_dir",
]