"""
XyaoTools Engine - Auto-Update System
Arch: Remote Version Synchronization & Hot-fix Injection
"""

from __future__ import annotations

import os
import subprocess
import threading
import time
import zipfile
from typing import Any, Dict, Optional

from api_manifest import store_last_message
from config import (
    UPDATE_CHECK_INTERVAL_SECONDS,
    UPDATE_PENDING_INFO,
    UPDATE_PENDING_ZIP,
)
from http_client import ensure_http_client
from logger import logger
from paths import backend_path, get_plugin_dir
from utils import (
    get_plugin_version,
    parse_version,
    write_json,
)

# Configuración del Repositorio de Xyao
RAW_VERSION_URL = "https://raw.githubusercontent.com/AnnonnimmusXyao/XyaomMKZ/main/version.txt"
UPDATE_ZIP_URL = "https://github.com/AnnonnimmusXyao/XyaomMKZ/raw/main/XyaoTools.zip"

_UPDATE_CHECK_THREAD: Optional[threading.Thread] = None

def apply_pending_update_if_any() -> str:
    """Aplica la extracción de parches calientes en el arranque si existe un paquete pendiente."""
    pending_zip = backend_path(UPDATE_PENDING_ZIP)
    pending_info = backend_path(UPDATE_PENDING_INFO)
    
    if not os.path.exists(pending_zip):
        return ""

    try:
        logger.log(f"XyaoTools Update: Aplicando parche desde {pending_zip}")
        with zipfile.ZipFile(pending_zip, "r") as archive:
            archive.extractall(get_plugin_dir())
        
        # Limpieza de residuos post-instalación
        try:
            os.remove(pending_zip)
            if os.path.exists(pending_info):
                os.remove(pending_info)
        except Exception:
            pass

        return "XyaoTools se ha actualizado correctamente. Reinicia Steam para aplicar cambios."
    except Exception as exc:
        logger.warn(f"XyaoTools Update: Error crítico en extracción: {exc}")
        return ""

def _fetch_remote_version() -> str:
    """Consulta el archivo version.txt en el repositorio de Xyao."""
    client = ensure_http_client("XyaoTools: RemoteVersion")
    try:
        logger.log(f"XyaoTools: Sincronizando versión con {RAW_VERSION_URL}")
        resp = client.get(RAW_VERSION_URL, timeout=10)
        resp.raise_for_status()
        # Limpiamos espacios o saltos de línea para evitar errores de parseo
        return resp.text.strip()
    except Exception as exc:
        logger.warn(f"XyaoTools: Fallo al consultar repositorio remoto: {exc}")
        return ""

def check_for_update_once() -> str:
    """Motor principal de comparación de versiones y descarga."""
    remote_version = _fetch_remote_version()
    if not remote_version:
        return ""

    current_version = get_plugin_version()
    
    # Análisis de jerarquía de versiones
    if parse_version(remote_version) <= parse_version(current_version):
        logger.log(f"XyaoTools: Sistema actualizado (Local: {current_version} | Remoto: {remote_version})")
        return ""

    logger.log(f"XyaoTools: Nueva versión detectada: {remote_version}. Iniciando descarga...")

    pending_zip = backend_path(UPDATE_PENDING_ZIP)
    client = ensure_http_client("XyaoTools: Downloader")

    try:
        with client.stream("GET", UPDATE_ZIP_URL, follow_redirects=True) as response:
            response.raise_for_status()
            with open(pending_zip, "wb") as output:
                for chunk in response.iter_bytes():
                    output.write(chunk)
        
        # Intento de extracción inmediata
        with zipfile.ZipFile(pending_zip, "r") as archive:
            archive.extractall(get_plugin_dir())
        
        logger.log(f"XyaoTools: Despliegue de versión {remote_version} completado.")
        return f"XyaoTools actualizado a v{remote_version}. Reinicia Steam."
        
    except Exception as exc:
        logger.warn(f"XyaoTools: Error durante la actualización automática: {exc}")
        return ""

def _periodic_update_check_worker():
    """Hilo persistente para auditoría de actualizaciones en segundo plano."""
    while True:
        try:
            # Espera definida en config.py (por defecto 2 horas)
            time.sleep(UPDATE_CHECK_INTERVAL_SECONDS)
            message = check_for_update_once()
            if message:
                store_last_message(message)
        except Exception as exc:
            logger.warn(f"XyaoTools: Error en el hilo de actualización: {exc}")

def start_auto_update_background_check() -> None:
    """Inicia el escrutinio de versiones en un hilo separado (Daemon)."""
    global _UPDATE_CHECK_THREAD
    if _UPDATE_CHECK_THREAD is None or not _UPDATE_CHECK_THREAD.is_alive():
        _UPDATE_CHECK_THREAD = threading.Thread(target=_periodic_update_check_worker, daemon=True)
        _UPDATE_CHECK_THREAD.start()
        logger.log("XyaoTools: Hilo de actualización periódica desplegado.")

def restart_steam_internal() -> bool:
    """Ejecuta el script de reinicio forzado de la instancia de Steam."""
    script_path = backend_path("restart_steam.cmd")
    if not os.path.exists(script_path):
        logger.error("XyaoTools: Script de reinicio no encontrado.")
        return False
    try:
        # 0x08000000 = CREATE_NO_WINDOW (Ejecución silenciosa)
        subprocess.Popen(["cmd", "/C", script_path], creationflags=0x08000000)
        return True
    except Exception as exc:
        logger.error(f"XyaoTools: Fallo al reiniciar el proceso Steam: {exc}")
        return False

def restart_steam() -> bool:
    return restart_steam_internal()

def check_for_updates_now() -> Dict[str, Any]:
    """Trigger manual desde la interfaz de usuario."""
    try:
        message = check_for_update_once()
        return {"success": True, "message": message}
    except Exception as exc:
        return {"success": False, "error": str(exc)}