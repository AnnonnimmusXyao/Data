"""
XyaoTools Engine - Locale Loader
Arch: Internationalization Manager
"""

from __future__ import annotations
import json
import os
import threading
from typing import Any, Dict, List, Optional, Tuple
from paths import backend_path
from logger import logger

DEFAULT_LOCALE = "es" # Cambiado a español por defecto
PLACEHOLDER_VALUE = "Traducción faltante"
LOCALES_DIR = backend_path("locales")

def _ensure_locales_dir() -> None:
    try:
        os.makedirs(LOCALES_DIR, exist_ok=True)
    except Exception as exc:
        logger.warn(f"XyaoTools: Error al asegurar carpeta de idiomas: {exc}")

class LocaleManager:
    def __init__(self):
        self._lock = threading.Lock()
        self._locales: Dict[str, Dict[str, Any]] = {}
        self._load_all()

    def _load_all(self):
        _ensure_locales_dir()
        for f in os.listdir(LOCALES_DIR):
            if f.endswith(".json"):
                code = f[:-5]
                try:
                    with open(os.path.join(LOCALES_DIR, f), "r", encoding="utf-8") as h:
                        self._locales[code] = json.load(h)
                except Exception as e:
                    logger.warn(f"XyaoTools: Fallo al cargar idioma {code}: {e}")

    def get_locale_strings(self, locale: str) -> Dict[str, str]:
        with self._lock:
            payload = self._locales.get(locale) or self._locales.get(DEFAULT_LOCALE)
            return dict(payload.get("strings", {})) if payload else {}

_LOCALE_MANAGER: Optional[LocaleManager] = None

def get_locale_manager() -> LocaleManager:
    global _LOCALE_MANAGER
    if _LOCALE_MANAGER is None:
        _LOCALE_MANAGER = LocaleManager()
    return _LOCALE_MANAGER