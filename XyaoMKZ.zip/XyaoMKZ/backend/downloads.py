"""
XyaoTools Engine - Download & Installation Core (Hybrid Version)
Arch: Multi-source Delivery (ZIP/RAW) & Script Sanitization
"""

from __future__ import annotations

import json
import os
import re
import threading
import zipfile
from typing import Any, Dict

import Millennium  # type: ignore

from api_manifest import load_api_manifest
from settings.manager import get_morrenus_api_key
from config import (
    USER_AGENT,
    WEBKIT_DIR_NAME,
    WEB_UI_ICON_FILE,
)
from http_client import ensure_http_client
from logger import logger
from paths import backend_path
from steam_utils import get_steam_path, has_lua_for_app
from utils import ensure_temp_download_dir

# Estados globales de descarga
DOWNLOAD_STATE: Dict[int, Dict[str, Any]] = {}
DOWNLOAD_LOCK = threading.Lock()

# Cache de metadatos de aplicaciones
APP_NAME_CACHE: Dict[int, str] = {}
APP_NAME_CACHE_LOCK = threading.Lock()

def _set_download_state(appid: int, update: dict) -> None:
    with DOWNLOAD_LOCK:
        state = DOWNLOAD_STATE.get(appid) or {}
        state.update(update)
        DOWNLOAD_STATE[appid] = state

def _get_download_state(appid: int) -> dict:
    with DOWNLOAD_LOCK:
        return DOWNLOAD_STATE.get(appid, {}).copy()

def _log_appid_event(action: str, appid: int, name: str) -> None:
    """Desactivado a petición de Xyao para ahorrar espacio y evitar logs innecesarios."""
    pass

def _sanitize_script_content(raw_content: str) -> str:
    """Aplica reglas de seguridad para evitar conflictos en Steam."""
    sanitized = ""
    for line in raw_content.splitlines(True):
        if "setManifestid(" in line and not line.strip().startswith("--"):
            line = "--" + line.lstrip()
        sanitized += line
    return sanitized

def _process_package_zip(appid: int, zip_path: str) -> None:
    """Extrae y sanitiza el contenido de un paquete de XyaoTools."""
    steam_base = get_steam_path()
    stplug_dir = os.path.join(steam_base, "config", "stplug-in")
    os.makedirs(stplug_dir, exist_ok=True)

    with zipfile.ZipFile(zip_path, "r") as archive:
        # Inyectar manifiestos si existen
        try:
            depot_dir = os.path.join(steam_base, "depotcache")
            os.makedirs(depot_dir, exist_ok=True)
            for item in archive.namelist():
                if item.lower().endswith(".manifest"):
                    with open(os.path.join(depot_dir, os.path.basename(item)), "wb") as f:
                        f.write(archive.read(item))
        except Exception as e:
            logger.warn(f"XyaoTools: Error inyectando manifiestos: {e}")

        # Buscar el script principal
        script_files = [f for f in archive.namelist() if re.fullmatch(r"\d+\.lua", os.path.basename(f))]
        if not script_files:
            raise RuntimeError("El paquete no contiene un script válido")

        chosen = next((f for f in script_files if os.path.basename(f) == f"{appid}.lua"), script_files[0])
        raw_content = archive.read(chosen).decode("utf-8", errors="replace")
        
        sanitized = _sanitize_script_content(raw_content)
        
        with open(os.path.join(stplug_dir, f"{appid}.lua"), "w", encoding="utf-8") as f:
            f.write(sanitized)

def _download_worker(appid: int):
    """Motor híbrido de descarga XyaoTools."""
    client = ensure_http_client("XyaoTools: Downloader")
    apis = load_api_manifest()
    temp_dir = ensure_temp_download_dir()
    mo_key = get_morrenus_api_key()

    for api in apis:
        if _get_download_state(appid).get("status") == "cancelled": return
        
        name = api.get("name", "Fuente")
        url_tpl = api.get("url", "").replace("<moapikey>", mo_key)
        url = url_tpl.replace("<appid>", str(appid))

        _set_download_state(appid, {"status": "checking", "currentApi": name})
        
        try:
            is_raw = url.lower().endswith(".lua")
            
            with client.stream("GET", url, follow_redirects=True) as resp:
                if resp.status_code != int(api.get("success_code", 200)):
                    continue

                _set_download_state(appid, {"status": "downloading"})
                
                if is_raw:
                    raw_text = resp.read().decode("utf-8", errors="replace")
                    sanitized = _sanitize_script_content(raw_text)
                    
                    steam_base = get_steam_path()
                    target_file = os.path.join(steam_base, "config", "stplug-in", f"{appid}.lua")
                    os.makedirs(os.path.dirname(target_file), exist_ok=True)
                    
                    with open(target_file, "w", encoding="utf-8") as f:
                        f.write(sanitized)
                else:
                    dest_zip = os.path.join(temp_dir, f"{appid}.zip")
                    with open(dest_zip, "wb") as f:
                        for chunk in resp.iter_bytes():
                            if _get_download_state(appid).get("status") == "cancelled":
                                raise RuntimeError("cancelled")
                            f.write(chunk)
                    
                    _set_download_state(appid, {"status": "processing"})
                    _process_package_zip(appid, dest_zip)
                    if os.path.exists(dest_zip): os.remove(dest_zip)

                _set_download_state(appid, {"status": "done", "success": True, "api": name})
                return

        except Exception as e:
            logger.warn(f"XyaoTools: Fallo en fuente {name}: {e}")

    _set_download_state(appid, {"status": "failed", "error": "No disponible en ninguna fuente"})

# --- Funciones de Interfaz (Bridge) ---

def start_add_via_luatools(appid: int, _="") -> str:
    """Inicia el hilo de descarga de XyaoTools."""
    # Resetear la memoria de "visto" para que este nuevo juego SI salga en el popup al terminar
    try:
        seen_path = backend_path("seen_apps.json")
        if os.path.exists(seen_path):
            with open(seen_path, "r") as f:
                seen_apps = json.load(f)
            if str(appid) in seen_apps: seen_apps.remove(str(appid))
            if appid in seen_apps: seen_apps.remove(appid)
            with open(seen_path, "w") as f:
                json.dump(seen_apps, f)
    except: pass

    _set_download_state(appid, {"status": "queued", "appid": appid})
    threading.Thread(target=_download_worker, args=(appid,), daemon=True).start()
    return json.dumps({"success": True})

def delete_luatools_for_app(appid: int, _="") -> str:
    """Elimina los scripts del disco."""
    steam_base = get_steam_path()
    target_dir = os.path.join(steam_base, "config", "stplug-in")
    files = [f"{appid}.lua", f"{appid}.lua.disabled"]
    
    count = 0
    for f in files:
        p = os.path.join(target_dir, f)
        if os.path.exists(p):
            os.remove(p)
            count += 1
    
    return json.dumps({"success": True, "count": count})

def fetch_app_name(appid: int) -> str:
    """Obtiene el nombre del juego (con cache)."""
    with APP_NAME_CACHE_LOCK:
        if appid in APP_NAME_CACHE: return APP_NAME_CACHE[appid]
    return f"Juego {appid}"

def get_add_status(appid: int, _="") -> str:
    return json.dumps({"success": True, "state": _get_download_state(appid)})