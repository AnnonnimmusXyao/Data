"""
XyaoTools Engine - Main Entry Point
Arch: Millennium Bridge & Subsystem Orchestrator
"""

import sys
import os
import base64
import json
import shutil
import webbrowser
import urllib.request
from typing import Any

# --- LÓGICA DE RUTAS ---
backend_dir = os.path.dirname(os.path.realpath(__file__))
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

import Millennium # type: ignore
from logger import logger

import api_manifest
import auto_update
import downloads
import fixes
import steam_utils
from config import WEBKIT_DIR_NAME, WEB_UI_ICON_FILE, WEB_UI_JS_FILE
from paths import get_plugin_dir, public_path, backend_path
from settings.manager import init_settings, get_settings_payload, apply_settings_changes

def _steam_ui_path() -> str:
    return os.path.join(Millennium.steam_path(), "steamui", WEBKIT_DIR_NAME)

def _deploy_webkit_assets():
    dst_root = _steam_ui_path()
    os.makedirs(dst_root, exist_ok=True)
    assets = [
        (public_path(WEB_UI_JS_FILE), os.path.join(dst_root, WEB_UI_JS_FILE)),
        (public_path(WEB_UI_ICON_FILE), os.path.join(dst_root, WEB_UI_ICON_FILE)),
        (os.path.join(get_plugin_dir(), "public", "themes"), os.path.join(dst_root, "themes"))
    ]
    for src, dst in assets:
        try:
            if os.path.isdir(src):
                if os.path.exists(dst): shutil.rmtree(dst)
                shutil.copytree(src, dst)
            elif os.path.exists(src):
                shutil.copy(src, dst)
        except Exception as e:
            logger.error(f"XyaoTools UI: Error desplegando {src}: {e}")

# ==========================================================
# INTERFAZ DE API PARA EL FRONTEND (BRIDGE)
# ==========================================================

class FrontendLogger:
    @staticmethod
    def log(message="", **kwargs):
        logger.log(f"[UI] {message}")
Logger = FrontendLogger()

def InitApis(**kwargs) -> str: return api_manifest.init_apis()
def GetApiList(**kwargs) -> str: return api_manifest.get_api_list()
def StartAddViaXyaoTools(appid: int, **kwargs) -> str: return downloads.start_add_via_luatools(appid)
def GetAddViaXyaoToolsStatus(appid: int, **kwargs) -> str: return downloads.get_add_status(appid)
def CancelAddViaXyaoTools(appid: int, **kwargs) -> str:
    try: downloads._set_download_state(appid, {"status": "cancelled", "error": "Cancelado"})
    except: pass
    return json.dumps({"success": True})

def HasXyaoToolsForApp(appid: int, **kwargs) -> str: 
    steam_base = steam_utils.get_steam_path()
    target_file = os.path.join(steam_base, "config", "stplug-in", f"{appid}.lua")
    target_disabled = os.path.join(steam_base, "config", "stplug-in", f"{appid}.lua.disabled")
    is_installed = os.path.exists(target_file) or os.path.exists(target_disabled)
    return json.dumps({"success": True, "exists": is_installed})

def _fetch_steam_name(appid: int) -> str:
    try:
        url = f"https://store.steampowered.com/api/appdetails?appids={appid}&filters=basic"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=1.5) as r:
            data = json.loads(r.read().decode('utf-8'))
            if str(appid) in data and data[str(appid)].get('success'):
                return data[str(appid)]['data']['name']
    except: pass
    return f"Juego {appid}"

# --- CORRECCIÓN: Popup inteligente solo para novedades ---
def ReadLoadedApps(**kwargs) -> str:
    """Detecta juegos recién añadidos comparándolos con la lista de conocidos."""
    steam_base = steam_utils.get_steam_path()
    stplug_dir = os.path.join(steam_base, "config", "stplug-in")
    
    settings = get_settings_payload().get("settings", {})
    known_apps = settings.get("known_apps", []) # AppIDs que el usuario ya 'descartó'
    
    new_apps = []
    if os.path.exists(stplug_dir):
        for f in os.listdir(stplug_dir):
            if f.endswith(".lua"):
                try: 
                    appid = int(f.split(".")[0])
                    # Si el AppID no está en la lista de conocidos, es una NOVEDAD
                    if appid not in known_apps and str(appid) not in known_apps:
                        new_apps.append({"appid": appid, "name": _fetch_steam_name(appid)})
                except: pass
    return json.dumps({"success": True, "apps": new_apps})

def DismissLoadedApps(**kwargs) -> str:
    """Marca todos los juegos actuales como 'conocidos' para que no vuelvan a salir."""
    steam_base = steam_utils.get_steam_path()
    stplug_dir = os.path.join(steam_base, "config", "stplug-in")
    current_list = []
    
    if os.path.exists(stplug_dir):
        for f in os.listdir(stplug_dir):
            if f.endswith(".lua"):
                try: current_list.append(int(f.split(".")[0]))
                except: pass
                
    apply_settings_changes({"known_apps": current_list})
    return json.dumps({"success": True})

# --- CORRECCIÓN: Sincronización de nombre para la lista de juegos ---
def GetInstalledXyaoScripts(**kwargs) -> str:
    """Escanea la carpeta de XyaoTools y lista los juegos instalados."""
    steam_base = steam_utils.get_steam_path()
    stplug_dir = os.path.join(steam_base, "config", "stplug-in")
    installed = []
    if os.path.exists(stplug_dir):
        for f in os.listdir(stplug_dir):
            if f.endswith(".lua") or f.endswith(".lua.disabled"):
                try:
                    appid_str = f.split(".")[0]
                    if not appid_str.isdigit(): continue
                    appid = int(appid_str)
                    path = os.path.join(stplug_dir, f)
                    is_disabled = f.endswith(".disabled")
                    installed.append({
                        "appid": appid,
                        "name": "Unknown Game", 
                        "status": "disabled" if is_disabled else "enabled",
                        "fileSize": f"{os.path.getsize(path)} B",
                        "modifiedDate": "N/A",
                        "path": path,
                        "isDisabled": is_disabled
                    })
                except: pass
    return json.dumps({"success": True, "scripts": installed})

# Mantenemos este alias por si el JS aún llama al nombre viejo
def GetInstalledLuaScripts(**kwargs) -> str: return GetInstalledXyaoScripts(**kwargs)

def DeleteXyaoToolsForApp(appid: int, **kwargs) -> str:
    return downloads.delete_luatools_for_app(appid)

# --- Métodos de Fixes ---
def CheckForFixes(appid: int, **kwargs) -> str: return fixes.check_for_fixes(appid)
def ApplyGameFix(appid=0, downloadUrl="", installPath="", fixType="", gameName="", **kwargs) -> str: 
    return fixes.apply_game_fix(appid, downloadUrl, installPath, fixType, gameName)

def GetInstalledFixes(**kwargs) -> str:
    try: return fixes.get_installed_fixes()
    except: return json.dumps({"success": True, "fixes": []})

def DeleteGameFix(appid: int, **kwargs) -> str:
    try: return fixes.delete_game_fix(appid)
    except: return json.dumps({"success": False})

def UnFixGame(appid: int, installPath="", **kwargs) -> str:
    try: return fixes.unfix_game(appid, installPath)
    except: return json.dumps({"success": False})

def GetUnfixStatus(appid: int, **kwargs) -> str:
    try: return fixes.get_unfix_status(appid)
    except: return json.dumps({"success": False})

# --- Utilidades ---
def GetGameInstallPath(appid: int, **kwargs) -> str: 
    return json.dumps(steam_utils.get_game_install_path_response(appid))

def OpenGameFolder(path="", **kwargs) -> str:
    if os.path.exists(path): os.startfile(path)
    return json.dumps({"success": True})

def RestartSteam(**kwargs) -> str:
    auto_update.restart_steam()
    return json.dumps({"success": True})

def OpenExternalUrl(url: str, **kwargs) -> str:
    clean_url = str(url).strip()
    if clean_url.startswith(("http://", "https://")):
        webbrowser.open(clean_url)
        return json.dumps({"success": True})
    return json.dumps({"success": False, "error": "URL no segura"})

# --- CORRECCIÓN: Temas y persistencia de ajustes ---
def GetSettingsConfig(**kwargs) -> str:
    themes_choices = [{"value": "original", "label": "Original (Azul)"}]
    try:
        themes_path = os.path.join(get_plugin_dir(), "public", "themes", "themes.json")
        with open(themes_path, "r", encoding="utf-8") as f:
            themes_data = json.load(f)
            themes_choices = [{"value": t.get("value", t.get("key")), "label": t.get("name", t.get("value"))} for t in themes_data]
    except: pass

    schema = [
        {
            "key": "general",
            "label": "Ajustes de Interfaz",
            "options": [
                {
                    "key": "theme",
                    "type": "select",
                    "label": "Tema Visual",
                    "default": "original",
                    "choices": themes_choices
                }
            ]
        }
    ]
    current_settings = get_settings_payload().get("settings", {})
    # Saneamiento de datos para Millennium
    values = current_settings if "general" in current_settings else {"general": current_settings}
    
    return json.dumps({
        "success": True, 
        "schema": schema, 
        "values": values,
        "schemaVersion": 1
    })

def ApplySettingsChanges(changes: Any = None, **kwargs) -> str:
    """Procesa y guarda los cambios de configuración del frontend."""
    payload = {}
    if "changesJson" in kwargs:
        try: payload = json.loads(kwargs["changesJson"])
        except: pass
    elif isinstance(changes, dict):
        payload = changes
        
    if payload:
        # Si recibimos el tema en la raíz, lo movemos a 'general'
        if "theme" in payload and "general" not in payload:
            payload = {"general": {"theme": payload["theme"]}}
        apply_settings_changes(payload)
        
    return json.dumps({"success": True})

def GetThemes(**kwargs) -> str:
    themes_path = os.path.join(get_plugin_dir(), "public", "themes", "themes.json")
    try:
        with open(themes_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            return json.dumps({"success": True, "themes": data})
    except: return json.dumps({"success": False, "themes": []})

def GetInitApisMessage(**kwargs) -> str: return json.dumps({"success": True, "message": ""})

def GetTranslations(language: str = "es", **kwargs) -> str:
    locales_dir = backend_path("locales")
    lang_file = os.path.join(locales_dir, f"{language}.json")
    if not os.path.exists(lang_file): lang_file = os.path.join(locales_dir, "en.json")
    try:
        with open(lang_file, "r", encoding="utf-8") as f: 
            data = json.load(f)
            return json.dumps({
                "success": True,
                "language": language,
                "strings": data.get("strings", {})
            })
    except: return json.dumps({"success": False})

def FetchFreeApisNow(**kwargs) -> str: return api_manifest.fetch_free_apis_now()
def CheckForUpdatesNow(**kwargs) -> str:
    auto_update.check_for_updates_now()
    return json.dumps({"success": True})

def GetIconDataUrl(**kwargs) -> str:
    icon_path = public_path(WEB_UI_ICON_FILE)
    try:
        with open(icon_path, "rb") as f:
            encoded = base64.b64encode(f.read()).decode("utf-8")
            return json.dumps({"success": True, "dataUrl": f"data:image/png;base64,{encoded}"})
    except: return json.dumps({"success": False, "dataUrl": ""})

def GetGamesDatabase(**kwargs) -> str: return json.dumps({"success": True, "db": {}})

# ==========================================================
# CLASE PRINCIPAL (Plugin)
# ==========================================================
class Plugin:
    def _front_end_loaded(self): _deploy_webkit_assets()
    def _load(self):
        logger.log(f"Iniciando XyaoTools Engine v{auto_update.get_plugin_version()}...")
        init_settings()
        msg = auto_update.apply_pending_update_if_any()
        if msg: api_manifest.store_last_message(msg)
        _deploy_webkit_assets()
        Millennium.add_browser_js(os.path.join(WEBKIT_DIR_NAME, WEB_UI_JS_FILE))
        auto_update.start_auto_update_background_check()
        Millennium.ready()
        logger.log("XyaoTools Engine listo y operativo.")
    def _unload(self): logger.log("Apagando XyaoTools Engine...")