"""
XyaoTools Engine - Filesystem Mapping
Arch: Path Resolution Layer
"""

import os

def get_backend_dir() -> str:
    """Retorna la ruta absoluta del núcleo del backend."""
    return os.path.dirname(os.path.realpath(__file__))

def get_plugin_dir() -> str:
    """Retorna la raíz del plugin XyaoTools."""
    return os.path.abspath(os.path.join(get_backend_dir(), ".."))

def backend_path(filename: str) -> str:
    """Resuelve archivos dentro de la carpeta backend."""
    return os.path.join(get_backend_dir(), filename)

def public_path(filename: str) -> str:
    """Resuelve recursos para la interfaz (JS, CSS, Imágenes)."""
    return os.path.join(get_plugin_dir(), "public", filename)