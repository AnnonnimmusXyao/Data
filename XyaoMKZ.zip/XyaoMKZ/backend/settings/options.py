from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

@dataclass(frozen=True)
class SettingOption:
    key: str
    label: str
    option_type: str
    default: Any
    description: str = ""
    choices: Optional[List[Dict[str, Any]]] = None
    requires_restart: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass(frozen=True)
class SettingGroup:
    key: str
    label: str
    description: str
    options: List[SettingOption]

# Definición del ADN de XyaoTools
SETTINGS_GROUPS: List[SettingGroup] = [
    SettingGroup(
        key="general",
        label="XyaoTools Core",
        description="Preferencias globales del motor XyaoTools.",
        options=[
            SettingOption(
                key="useSteamLanguage",
                label="Idioma Automático",
                option_type="toggle",
                description="Sincronizar el idioma de la interfaz con el cliente de Steam.",
                default=True,
                metadata={"yesLabel": "Sí", "noLabel": "No"},
            ),
            SettingOption(
                key="language",
                label="Idioma Forzado",
                option_type="select",
                description="Seleccionar manualmente el idioma de XyaoTools.",
                default="es", # Default en español para tu versión
                metadata={"dynamicChoices": "locales"},
            ),
            SettingOption(
                key="theme",
                label="Interfaz Visual",
                option_type="select",
                description="Esquema de colores para el dashboard de XyaoTools.",
                default="original",
                metadata={"dynamicChoices": "themes"},
            ),
            SettingOption(
                key="morrenusApiKey",
                label="Clave API Morrenus",
                option_type="text",
                description="Token necesario para usar Sadie Source.",
                default="",
                metadata={"placeholder": "Introduce tu API Key..."},
            ),
        ],
    ),
]

def get_settings_schema() -> List[Dict[str, Any]]:
    """Genera la representación serializable del esquema para el Frontend."""
    schema: List[Dict[str, Any]] = []
    for group in SETTINGS_GROUPS:
        schema.append({
            "key": group.key,
            "label": group.label,
            "description": group.description,
            "options": [
                {
                    "key": opt.key,
                    "label": opt.label,
                    "type": opt.option_type,
                    "description": opt.description,
                    "default": opt.default,
                    "choices": opt.choices or [],
                    "requiresRestart": opt.requires_restart,
                    "metadata": opt.metadata,
                } for opt in group.options
            ],
        })
    return schema

def get_default_settings_values() -> Dict[str, Any]:
    """Obtiene los valores por defecto del sistema."""
    defaults: Dict[str, Any] = {}
    for group in SETTINGS_GROUPS:
        defaults[group.key] = {opt.key: opt.default for opt in group.options}
    return defaults

def merge_defaults_with_values(values: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Fusiona la persistencia con el esquema actual de forma atómica."""
    merged = values.copy() if isinstance(values, dict) else {}
    defaults = get_default_settings_values()

    for group_key, group_defaults in defaults.items():
        existing_group = merged.get(group_key, {})
        if not isinstance(existing_group, dict):
            existing_group = {}
        merged[group_key] = {**group_defaults, **existing_group}
    return merged